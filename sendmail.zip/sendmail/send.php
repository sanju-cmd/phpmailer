<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
	$mail->SMTPDebug = 2;									
	$mail->isSMTP();											
	$mail->Host	 = 'lo8.pwh-r1.com';					
	$mail->SMTPAuth = true;							
	$mail->Username = 'test1@appsscriptexpert.com';				
	$mail->Password = '0[mkiUMb?B.I';						
	$mail->SMTPSecure = 'TLS';							
	$mail->Port	 = 587 ;

	$mail->setfrom('test1@appsscriptexpert.com', 'Test Server');	
	$mail->addaddress('sanjaychaurasiya978@gmail.com', 'Name');
	
	$mail->isHTML(true);								
	$mail->Subject = 'Subject';
	$mail->Body = 'HTML message body in <b>bold</b> ';
	//$mail->addAttachment('C:/xampp/htdocs/sendmail/test.pdf', $name = 'test',  $encoding = 'base64', $type = 'application/pdf');
	$mail->AltBody = 'Body in plain text for non-HTML mail clients';
	$mail->send();
	echo "Mail has been sent successfully!";
} catch (Exception $e) {
	echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}



?>